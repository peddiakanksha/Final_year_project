<?php 
	require_once("lib/function.php");
	$db = new login_function();

	$app_id  = 1;
	$flag = 0;
	$application_name	=	"";	
	$success_msg = 0;
	$image_error="";
	
	$message_title				=	"";
	$description		=	"";

	if(isset($_POST['add_btn']))
	{	
		$application_name	= 1;
		$message_title 		= $_POST['title'];
		$valid_formats = array("jpg","png","gif","bmp","jpeg","pdf","JPEG","JPG","BMP","PNG","GIF","PDF");
	
		if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
		{	
			$name 				= 	$_FILES['picture']['name'];
			$size 				= 	$_FILES['picture']['size'];

			if(strlen($name))
				{				
					list($txt, $ext) = explode(".", $name);
					
					if(in_array($ext,$valid_formats))
					{
						$files	=	array();

						function generateRandomString($length = 10) {
							$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
							$charactersLength = strlen($characters);
							$randomString = '';
							for ($i = 0; $i < $length; $i++) 
							{
								$randomString .= $characters[rand(0, $charactersLength - 1)];
							}
							return $randomString;
						}
						
						$current_random_string = generateRandomString();
						
						$actual_image_name = $current_random_string.".".strtolower($ext);						

						$tmp = $_FILES['picture']['tmp_name'];
						
						$img_Dir = "slider_image/";
						
						if(!file_exists($img_Dir))
						{
							mkdir($img_Dir);
						}
						
						if(move_uploaded_file($tmp,$img_Dir.$actual_image_name))
						{
							
						}
						else
						{
							$image_error	=	"failed" ;
							$flag				=	1;
						}	
					}
					else
					{
						$image_error	= "Invalid file format";
						$flag				=	1;	
					}	
				}	
		}
		
		if($flag==0)
		{
			if($db->add_slider_images($actual_image_name,$message_title,$application_name))
			{
				$success_msg = 1 ;
				
				
			}
			else
			{
				$success_msg = 2 ;
			}
		}
	}
	if(isset($_GET['delete_id']))
	{
		 $del_id	=	$_GET['delete_id'];
		 
		 $db->delete_slider_images($del_id);

		 $success_msg	=	3;
	}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title><?php echo $project_title; ?></title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	 <link href="datatable/datatables.min.css" rel="stylesheet" />
	 <link href="css/app.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
}
@media only screen and (max-width: 600px) {
	.col-md-12
	{
		width:100%;
	}
	.alert
	{
		width:100%;
	}
	.side-row
	{
		width:49%;
		display:inline-table;
	}
}

</style>
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>

</head>
<body class="fixed-navbar">
<div class="page-wrapper">
<?php include('header.php'); ?>
<?php include('side-bar.php'); ?>
<div class="content-wrapper">
<div class="row">
<div class="col-md-12">
	<?php

if($success_msg==1)
{
?>

<script type="text/javascript">
	alert("Slider Image Added Successfully");
	//window.location = "add-rate-list.php";
</script>
<?php
}
?>
<?php
if($success_msg==2)
{
?>
	<div class="alert alert-danger" style="width:500px; margin:auto;">
	<span class="alert-link">Failed!</span> to send push notification
	</div>
<?php
}
?>

<div class="ibox">
		
<form class="form-pink" method="post" id="main_form" action="<?php echo $_SERVER['PHP_SELF']?>" name="myForm" onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data">

<div class="ibox-head">
	<div class="ibox-title"><i class="fas fa-image" style="margin-right:10px;"></i>
Add Highlight Image</div>
</div>
<div class="ibox-body">
	<div class="row">
	

				<div class="col-sm-4 form-group mb-4">
					<label class="form-group mb-4 set-row"><b>Slider Image</b></label>
					<div class="input-group-icon input-group-icon-left  set-row">
						<span class="input-icon input-icon-left"><i class="fas fa-list"></i></span>
						 <input class="form-control form-control-air " placeholder="Enter Slider Image" name="picture" type="file" required >
						
					</div>
					</div>		
				<div class="col-sm-4 form-group mb-4">
					<label class="form-group mb-4 set-row"><b>Image URL</b></label>
					<div class="input-group-icon input-group-icon-left  set-row">
						<span class="input-icon input-icon-left"><i class="fas fa-edit"></i></span>
						<input type="text" name="title" class="form-control form-control-air" value="<?php echo $message_title; ?>" placeholder="Title" required />
					</div>
				</div>
		<div class="col-sm-12 form-group mb-12" style="text-align:center;">
			<center><button class="btn btn-pink btn-air mr-2" type="submit" id="submit_btn" name="add_btn">Add Slider Image</button></center>
		</div>

	</div>
</div>

</form>
</div>
 <?php 
		if($success_msg == 3)
		{
		?>
		<script type="text/javascript">
			alert("Slider Image Deleted Successfully");
		</script>
	<?php 
		} 
	?>
	<div class="page-content fade-in-up" style="width:100%;">
	<div class="ibox">
		<div class="ibox-body">
			<h5 class="font-strong mb-4">Slider Image Report</h5>
			<div class="flexbox mb-4">
				<div class="input-group-icon input-group-icon-left mr-3">
					<span class="input-icon input-icon-right font-16"><i class="fas fa-search"></i></span>
					<input class="form-control form-control-rounded form-control-solid" id="key-search" type="text" placeholder="Search ...">
				</div>
			</div>
			<div class="table-responsive row">
			<table class="table table-bordered table-hover" id="example" style="overflow-x:auto;overflow-y:auto;">
				<thead class="thead-default thead-lg">
					<tr>
						<th>SR</th> 
						<th>Application Name</th> 
						<th>Slider Image</th>
						<th>URL</th> 						
						<th>Delete</th> 
					</tr>
				</thead>
				<tbody>
				<?php
					$report_details = $db->get_all_slider_images($app_id);
					if(!empty($report_details))
					{
						$counter =0;
						foreach($report_details as $record)
						{
							$id				=	$report_details[$counter][0];
							$images			=	$report_details[$counter][1];
							$title			=	$report_details[$counter][2];
							$application_id =	$report_details[$counter][3];
							$app_name		=	1;
				?>
				<tr> 
					<td><?php echo $counter+1; ?></td>
					<td><?php echo $app_name; ?></td>
					<?php
					if($images!="")
					{
					?>
					<td><a href="slider_image/<?php echo $images; ?>" target="_blank"><img src="slider_image/<?php echo $images; ?>" height="50px" width="50px"></a></td>
					
					<?php
					}
					else
					{
					?>
					<td><a href="slider_image/no_image_available.png" target="_blank"><img src="slider_image/no_image_available.png" height="50px" width="100px"></a></td>
					
					<?php
						
					}
					?>	
					<td><?php echo $title; ?></td>
					<td><a href="add-slider-images.php?delete_id=<?php echo $id; ?>&image=<?php echo $images;?>" onclick="return confirm('Are you Sure to Delete this Image?');"><i class="fas fa-trash"style="color:red;margin-left:20px;"></i></td>
													
				</tr> 
				<?php
						$counter++;		
						}
				}
				
				?>
				</tbody> 
			</table> 
		</div>
	</div>
	</div>
</div>

</div>
</div>

	</div>

</div>
</div>
</div>
    </div>

    <!-- END SEARCH PANEL-->
    <!-- BEGIN THEME CONFIG PANEL-->
    
    <!-- END THEME CONFIG PANEL-->
    <!-- BEGIN PAGA BACKDROPS-->
    <div class="sidenav-backdrop backdrop"></div>
    <div class="preloader-backdrop">
        <div class="page-preloader">Loading</div>
    </div>
    <!-- END PAGA BACKDROPS-->
    <!-- New question dialog-->
    
    <!-- End New question dialog-->
    <!-- QUICK SIDEBAR-->
	
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/metisMenu.min.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script src="js/idle-timer.min.js"></script>
    <script src="js/toastr.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/bootstrap-select.min.js"></script>
    <!-- PAGE LEVEL PLUGINS-->
    <!-- CORE SCRIPTS-->
	<script src="datatable/datatables.min.js"></script>
    <script src="js/app.min.js"></script>

<script type="text/javascript" src="http://js.nicedit.com/nicEdit-latest.js"></script> <script type="text/javascript">
//<![CDATA[
        bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
  //]]>
  </script>
</body>

</html>