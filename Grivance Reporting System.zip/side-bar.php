<style>
.table-responsive
{
	font-size:11px !important;
}
tr th
{
	background-color:#DE1559 !important;
	color:#FFFFFF !important;
	font-size:12px;
}
tr td
{
	color:#000000 !important;
	font-size:12px;
}
.company_logo
{
	color:#DAAADB !important;
	font-size:12px !important;
	width:200px !important;
}
.company_logo:hover
{
	text-decoration:underline;
	color:#98E0AD !important;
}
.label_marg
{
	margin-bottom:4px !important;
	font-size:12px;
	color:#232B99;
}
.form-control
{
	color:#333 !important;
}
.ibox-title
{
	font-size:22px !important;
	color:#DE1559 !important;
}
.content-wrapper
{
	padding-top:65px !important;
	background-image:url('images/back6.jpg');
	background-size:100% 100%;
	background-repeat: no-repeat;
	min-height:1000px !important;
}
.ibox .ibox-head {
	border-bottom: 1px dotted #f75a5f !important;
}
.mb-4
{
	margin-bottom:4px !important;
	font-size:12px;
	color:#232B99;
}
.mb6
{
	margin-bottom:4px !important;
	font-size:12px;
	color:red;
}
hr 
{
	
	border-bottom: 1px dotted #232B99 !important;

}
</style>
<header class="header">
	<div class="page-brand" style="background-color:#000;">
		
			<span class="brand" style="font-size:20px;">Grievance Portal</span>
			<span class="brand">
			<?php
				if(isset($_SESSION['current_login_user']))
				{
			?>
				- User
			<?php	
				}
				else if(isset($_SESSION['current_login_officer']))
				{
			?>
				- Officer
			<?php	
				}
				else
				{
			?>
				- Admin
			<?php		
				}
			?>
			</span>
		
	</div>
	<div class="flexbox flex-1">
		<!-- START TOP-LEFT TOOLBAR-->
		<ul class="nav navbar-toolbar">
			<li>
				<a class="nav-link sidebar-toggler js-sidebar-toggler" href="javascript:;">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
			</li>
			
		</ul>
		
	</div>
</header>
<nav class="page-sidebar" id="sidebar" style="background-color:#333333;">
	<div id="sidebar-collapse">
		<ul class="side-menu metismenu">
		    <li>
				<a href="dashboard.php"><i class="sidebar-item-icon fas fa-home"></i>
				<span class="nav-label">Dashboard</span></a>
			</li>
			<?php
				if(isset($_SESSION['current_login_user']))
				{
			?>
			<li>
				<a href="add-complaint.php"><i class="sidebar-item-icon fas fa-users-cog"></i>
				<span class="nav-label">Add Complaint</span></a>
			</li>
			<li>
				<a href="my-complaint-list.php"><i class="sidebar-item-icon fas fa-users-cog"></i>
				<span class="nav-label">My Complaint Report</span></a>
			</li>
			
			<li>
				<a href="admin-complaint.php"><i class="sidebar-item-icon fas fa-users-cog"></i>
				<span class="nav-label">Admin Complaint</span></a>
			</li>
			
			<li>
				<a href="user-change-password.php"><i class="sidebar-item-icon far fa-arrow-alt-circle-right"></i>
				<span class="nav-label">Change Password</span></a>
			</li>
			<?php			
				}
				else if(isset($_SESSION['current_login_admin']))
				{
					
			?>
			<li>
				<a href="add_post.php"><i class="sidebar-item-icon fas fa-users-cog"></i>
				<span class="nav-label">Add Post/Meeting/Info</span></a>
			</li>
			<li>
				<a href="posts-report.php"><i class="sidebar-item-icon fas fa-users-cog"></i>
				<span class="nav-label">Posts Report</span></a>
			</li>
			<li>
				<a href="add-slider-images.php"><i class="sidebar-item-icon far fa-arrow-alt-circle-right"></i>
				<span class="nav-label">Highlight Images</span></a>
			</li>
			<li>
				<a href="user_report.php"><i class="sidebar-item-icon far fa-arrow-alt-circle-right"></i>
				<span class="nav-label">User Report</span></a>
			</li>
			<li>
				<a href="complaint-list.php"><i class="sidebar-item-icon fas fa-users-cog"></i>
				<span class="nav-label">Pending Complaints</span></a>
			</li>
			<li>
				<a href="completed-complaint-list.php"><i class="sidebar-item-icon fas fa-users-cog"></i>
				<span class="nav-label">Resolved Complaints</span></a>
			</li>
			<li>
				<a href="change-password.php"><i class="sidebar-item-icon far fa-arrow-alt-circle-right"></i>
				<span class="nav-label">Change Password</span></a>
			</li>
			<?php
				}
				else if(isset($_SESSION['current_login_officer']))
				{
			?>
			<li>
				<a href="admin-complaint-list.php"><i class="sidebar-item-icon fas fa-users-cog"></i>
				<span class="nav-label">Pending Complaints</span></a>
			</li>
			<li>
				<a href="admin-completed-complaint-list.php"><i class="sidebar-item-icon fas fa-users-cog"></i>
				<span class="nav-label">Resolved Complaints</span></a>
			</li>
			<li>
				<a href="officer-change-password.php"><i class="sidebar-item-icon far fa-arrow-alt-circle-right"></i>
				<span class="nav-label">Change Password</span></a>
			</li>
			<?php
				}
			?>
			
			
			<li>
				<a href="index.php?logout">
				<i class="sidebar-item-icon far fa-arrow-alt-circle-right"></i>
				<span class="nav-label">Logout</span></a>
				
			  </li>
			  
	
			<li style="color:orange; text-align:center;">
			
			<br />
			Change Language
			<br />
			
	<div id="google_translate_element"></div>
 
 <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement(
                {pageLanguage: 'en'},
                'google_translate_element'
            );
        }
    </script>
	
	<script type="text/javascript"
            src=
"https://translate.google.com/translate_a/element.js?
cb=googleTranslateElementInit">
    </script>
			</li>
			
			
		</ul>
	</div>
</nav>