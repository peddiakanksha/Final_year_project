<?php
    ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

    echo file_get_contents('https://kanakaratnaservices.in/New_pan/apply_new_pan.asp');
?>