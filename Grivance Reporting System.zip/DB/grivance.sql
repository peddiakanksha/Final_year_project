-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 25, 2023 at 03:24 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `grivance`
--
CREATE DATABASE IF NOT EXISTS `grivance` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `grivance`;

-- --------------------------------------------------------

--
-- Table structure for table `add_complaint`
--

CREATE TABLE IF NOT EXISTS `add_complaint` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` text COLLATE utf8_unicode_ci NOT NULL,
  `complaint_about` text COLLATE utf8_unicode_ci NOT NULL,
  `description_one` text COLLATE utf8_unicode_ci NOT NULL,
  `image_one` text COLLATE utf8_unicode_ci NOT NULL,
  `image_two` text COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` text COLLATE utf8_unicode_ci NOT NULL,
  `village` text COLLATE utf8_unicode_ci NOT NULL,
  `status` text COLLATE utf8_unicode_ci NOT NULL,
  `location` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

--
-- Dumping data for table `add_complaint`
--

INSERT INTO `add_complaint` (`id`, `user_id`, `complaint_about`, `description_one`, `image_one`, `image_two`, `date`, `time`, `village`, `status`, `location`) VALUES
(11, 'user id 6565', 'complaint About', 'one', 'image one', 'image two', '2023-04-14', '17:02:39', '', 'pending', ''),
(12, 'user id', 'about', 'des one ', 'image one', 'imge two', '2023-04-17', '10:51:14', '', 'pending', ''),
(13, '7788995588', 'Raste', 'dfsdfdfsdf', '9aYEJNSago.png', '00b4A1uplz.png', '2023-05-14', '20:39:27', '', 'pending', ''),
(14, '7788995588', 'Pani', 'fghfghfgh', 'Y3qmL1m3RY.png', '4xBpF2PhKg.png', '2023-05-14', '20:39:44', '', 'pending', ''),
(15, '7788995588', 'Pani', 'fghfghfgh', 'T3nrDHbioG.png', 'f21Y9nR30y.png', '2023-05-14', '20:41:06', '', 'pending', ''),
(18, '9028751834', 'Kachra', 'dddd', 'f4Wvbj7Ppp.jpg', 'UlqswVb2FT.jpg', '2023-05-24', '22:43:16', '', 'pending', ''),
(17, '7788995588', 'Kachra', 'sdfsdfsdf', 'w7bbsMgglY.png', '2V1E5SRixl.png', '2023-05-14', '20:42:07', '', 'pending', ''),
(19, '9028751834', 'Kachra', 'ddddd', 'ejgjWxNvbC.png', '45MwHM5GLN.jpg', '2023-05-24', '22:49:27', '77', 'pending', ''),
(20, '9028751834', 'Hotgi', 'sdfsdf', 'drRNb1aXK5.jpg', 'BeSgUX1DhZ.png', '2023-05-24', '22:53:29', '77', 'pending', ''),
(21, '9028751834', 'Hotgi', 'sdfsdf', 'bMsFNPDPRk.jpg', 'yPOpqvEEXd.png', '2023-05-24', '22:54:04', '77', 'completed', ''),
(22, '9028751834', 'Raste', 'fghfgdh', 'dKv7hKRAYF.jpg', 'DQLA2HB6Ow.png', '2023-05-24', '22:56:20', 'Hotgi', 'completed', ''),
(23, '9028751834', 'Kachra', 'Problme Description', 'QifB1YRDc8.jpg', 'U978SdZPHs.jpg', '2023-05-24', '23:54:24', 'Hotgi', 'pending', 'https://goo.gl/maps/11Xz74ic1PCZTbid6');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `password`) VALUES
(1, 'admin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `complaint_about_officer`
--

CREATE TABLE IF NOT EXISTS `complaint_about_officer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` text COLLATE utf8_unicode_ci NOT NULL,
  `complaint_about` text COLLATE utf8_unicode_ci NOT NULL,
  `description_one` text COLLATE utf8_unicode_ci NOT NULL,
  `image_one` text COLLATE utf8_unicode_ci NOT NULL,
  `image_two` text COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` text COLLATE utf8_unicode_ci NOT NULL,
  `village` text COLLATE utf8_unicode_ci NOT NULL,
  `status` text COLLATE utf8_unicode_ci NOT NULL,
  `location` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `complaint_about_officer`
--

INSERT INTO `complaint_about_officer` (`id`, `user_id`, `complaint_about`, `description_one`, `image_one`, `image_two`, `date`, `time`, `village`, `status`, `location`) VALUES
(1, '9028751834', 'AAAAAA', 'AAffdf ', 'w7Auwv44gz.png', 'hC6NjnR9L3.png', '2023-05-25', '20:15:42', 'Hotgi', 'completed', 'fghfghfghgh');

-- --------------------------------------------------------

--
-- Table structure for table `entry`
--

CREATE TABLE IF NOT EXISTS `entry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` text COLLATE utf8_unicode_ci NOT NULL,
  `mo_no` text COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `date` text COLLATE utf8_unicode_ci NOT NULL,
  `time` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=57 ;

--
-- Dumping data for table `entry`
--

INSERT INTO `entry` (`id`, `full_name`, `mo_no`, `address`, `email`, `password`, `date`, `time`) VALUES
(55, 'siddh', '9028751834', 'shelgi', 'abc@gmail.com', '123', '2023-04-14', '09:16:33 pm'),
(54, 'siddharam', '9028751834', 'shelgi', 'abc@gmail.com', '123', '2023-04-14', '09:14:05 pm'),
(52, 'yogiraj', '8605965201', 'solapur', 'abc@gmail.com', '789', '2023-04-13', '10:55:32 am'),
(53, 'chaitanya', '8421034699', 'shelgi', 'abc@gmail.com', '123', '2023-04-13', '11:48:31 am'),
(48, 'Rohit', '9730104829', 'pune', 'rohit@gmail.com', '789', '2023-04-12', '12:45:03 pm'),
(49, 'abhishek', '7796794971', 'solapur', 'abhi@gmail.com', '123', '2023-04-12', '09:36:41 pm'),
(44, 'shivani', '9730104829', 'shelgi', 'abc@gmail.com', '12345', '2023-04-12', '12:23:48 pm'),
(56, 'aaa', '7788995588', 'ddd', '54sdsd', '55', '2023-05-14', '08:09:08 pm');

-- --------------------------------------------------------

--
-- Table structure for table `officer`
--

CREATE TABLE IF NOT EXISTS `officer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `officer`
--

INSERT INTO `officer` (`id`, `admin_name`, `password`) VALUES
(1, 'chiefadmin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` text COLLATE utf8_unicode_ci NOT NULL,
  `complaint_about` text COLLATE utf8_unicode_ci NOT NULL,
  `description_one` text COLLATE utf8_unicode_ci NOT NULL,
  `image_one` text COLLATE utf8_unicode_ci NOT NULL,
  `image_two` text COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` text COLLATE utf8_unicode_ci NOT NULL,
  `village` text COLLATE utf8_unicode_ci NOT NULL,
  `status` text COLLATE utf8_unicode_ci NOT NULL,
  `location` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `complaint_about`, `description_one`, `image_one`, `image_two`, `date`, `time`, `village`, `status`, `location`) VALUES
(3, 'admin', 'Meeting Of Swacchata Abhiyan', 'Grapmpanchayat Musti Is Arranged a Meeting For Swacchta Abhiyan In Musti Grampanchayat Office At 11.00 AM. This is invitaion to all public members to attend the meeting.', '0bLDL7jy9Y.png', 'geCPRx9hPN.png', '2023-05-25', '19:41:36', 'Musti', 'pending', 'https://goo.gl/maps/uirZis5ezSoS3xVbA'),
(2, 'admin', 'Majarewadi Road Work Completed', 'In Solapur City Majarewadi Road Work Completed.. Road Construction Is Of Cement', 'ZI9F01ZmYj.jpg', '4olGAB4Hhk.jpg', '2023-05-25', '00:40:43', 'Hotgi', 'pending', 'https://goo.gl/maps/bDhDYkognwcmNnBr6');

-- --------------------------------------------------------

--
-- Table structure for table `slider_images`
--

CREATE TABLE IF NOT EXISTS `slider_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `url` text COLLATE utf8_unicode_ci NOT NULL,
  `application_id` text COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=59 ;

--
-- Dumping data for table `slider_images`
--

INSERT INTO `slider_images` (`id`, `image`, `url`, `application_id`, `date`, `time`) VALUES
(57, 'vBJPTEoVtt.png', '-', '1', '2023-05-15', '12:01:08'),
(58, 'ZQ738j9QTx.png', '-', '1', '2023-05-15', '12:01:40');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
