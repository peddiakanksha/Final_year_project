<?php
	require_once('lib/function.php');
	$db		=	new login_function();

	if(isset($_SESSION['current_login_admin']))
	{
		$current_login_admin	=	$_SESSION['current_login_admin'];
	}
	
	if(isset($_SESSION['current_login_user']))
	{
		$current_login_user	=	$_SESSION['current_login_user'];
	}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>Dashboard</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<!--<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">-->
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
  #youtube_vdo
  {
	 float:right;
  }
  #youtube_vdo iframe
  {
	height:150px;
	width:150px;
	margin-top:-30px;
  }
  </style>
    <!-- PAGE LEVEL STYLES-->
</head>

<body class="fixed-navbar">
    <div class="page-wrapper">
	
        <!-- START HEADER-->
        <?php include('header.php'); ?>
        <!-- END HEADER-->
        <!-- START SIDEBAR-->
        <?php include('side-bar.php'); ?>

        <div class="content-wrapper" style="<?php if(isset($_SESSION['current_login_admin'])){ ?> background-image:url('grievances.png'); background-size:100% 71%; <?php } ?>">
		
		<?php
				if(isset($_SESSION['current_login_user']))
				{
			?>
		
		  <div id="myCarousel" class="carousel slide" data-ride="carousel">
				<div class="carousel-inner">
			<?php
				$application_id	=	1;
				$data=$db->get_all_slider_image_details($application_id);
//print_r($data);
				if(!empty($data))
				{
					$counter=0;
					foreach($data as $record)
					{
							$res_id             		=   $record['res_id'];
							$slider_image        		=   $record['image'];
							$image_url        			=   $record['image_url'];
							$attachment[$counter]['slider_image']=$slider_image;
							$attachment[$counter]['image_url']	 =$image_url;
							?>
							<div class="item <?php if($counter==0){ ?> active<?php } ?>">
						 	 <img src="slider_image/<?php echo $slider_image; ?>" alt="" style="width:100%; height:320px !important;">
						  </div>
						<?php
							$counter ++;
					}
				}
			?>
	  	 <!-- Wrapper for slides -->
	    </div>

	    <!-- Left and right controls -->
	    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
	      <span class="glyphicon glyphicon-chevron-left"></span>
	      <span class="sr-only">Previous</span>
	    </a>
	    <a class="right carousel-control" href="#myCarousel" data-slide="next">
	      <span class="glyphicon glyphicon-chevron-right"></span>
	      <span class="sr-only">Next</span>
	    </a>
	</div>
		
		
		<br />
		<br />
		
		<?php
			$status_type = "";
			$village	 = "";
			$complaint_type  =	"";
			$report_details = $db->get_all_posts_report_data($status_type,$village,$complaint_type);
			if(!empty($report_details))
			{
				$counter =0;
				foreach($report_details as $record)
				{
					$id				=	$report_details[$counter][0];
					$user_id	=	$report_details[$counter][1];
					$complaint_about	=	$report_details[$counter][2];
					$description_one	=	$report_details[$counter][3];
					$image_one        =	$report_details[$counter][4];
					$image_two= $report_details[$counter][5];
				
					$date     =   $report_details[$counter][6];
				   $time  =   $report_details[$counter][7];
					$status	=	$report_details[$counter][8];
					$village	=	$report_details[$counter][9];
					$location =	$report_details[$counter][10];
					
		?>
			 <div class="odd gradeX" style="padding:10px; background-color:#FFF; border:1px dashed #666666; line-height:25px; <?php if($counter!=0){ ?> margin-top:20px; <?php } ?>">
				
				<div style="font-weight:bold; text-align:center; font-size:15px; margin-top:0px; color:#0070C0;"><?php echo $complaint_about; ?></div>
				
				<hr style="margin:5px;" />
				
				<div><?php echo $description_one; ?>
				<br />
				
				
				<strong>Area/Village : </strong>
				<?php echo $village; ?>
				
				
				<?php
					if($location != "")
					{
						if (strpos($location, 'youtube.com') !== false)
						{
							
						}
					}
					else
					{
				?>
				<strong style="margin-left:30px;">Map Location : </strong><a href="<?php echo $location; ?>" target="_blank">Click For Location</a>
				<?php
					}
				?>
				<br />
				
				<strong>Posted By : </strong>Admin
				
				<strong style="margin-left:30px;">Posted Date : </strong><?php echo $date; ?> <?php echo $time; ?>
				
				</div>
				<div id="youtube_vdo" style="float:display:inline-table;">
				<?php 
				if($location != "")
				{
					if (strpos($location, 'youtube.com') !== false)
					{
						echo $location;
					}
				}
				?>
				</div>
				<div style="float:left;">
				<?php if($image_one != "")
					{
					?>
					<a href="images/<?php echo $image_one; ?>" target="_blank"><img src="images/<?php echo $image_one; ?>" height="100px" width="100px" style="padding:5px; margin:4px; border:1px dashed #A349A4; border-radius:16px;"></a>
					<?php
					}else
					{
					?>
					<img src="logo/no-image.png" height="50px" width="50px"></a>
					<?php
					}
					?>
				</div>
				<div style="float:display:inline-table;">
				<?php if($image_two != "")
					{
					?>
					<a href="images/<?php echo $image_two; ?>" target="_blank"><img src="images/<?php echo $image_two; ?>" height="100px" width="100px" style="padding:5px; margin:4px; border:1px dashed #A349A4; border-radius:16px;"></a>
					<?php
					}else
					{
					?>
					<img src="logo/no-image.png" height="50px" width="50px"></a>
					<?php
					}
					?>
				</div>
			</div> 
			<?php
				$counter++;
				}
			}
		?>
		
		<?php
			}
			else				
			{
		?>
		<a href="total_complaints.php" style="padding:15px; border:1px solid #DFDFDF; text-align:center; margin:20px; background-color:#FFF; font-weight:bold; font-size:17px; width:230px; text-decoration:none; display:inline-table; color:purple;">Total Complaints
		<br />
		<?php
			$type = "";
			$total_count = $db->get_complaints_count($type);
		?>
		<label style="font-size:25px; margin-top:5px;"><?php echo $total_count; ?></label>
		</a>
		
		<a href="completed-complaint-list.php" style="padding:15px; border:1px solid #DFDFDF; text-align:center; margin:20px; background-color:#FFF; font-weight:bold; font-size:17px; width:230px; text-decoration:none; display:inline-table; color:green;">Resolved Complaints
		<br />
		
		<?php
			$type = "completed";
			$c_count = $db->get_complaints_count($type);
		?>
		<label style="font-size:25px; margin-top:5px;"><?php echo $c_count; ?>
		</a>
		
		<a href="complaint-list.php" style="padding:15px; border:1px solid #DFDFDF; text-align:center; margin:20px; background-color:#FFF; font-weight:bold; font-size:17px; width:230px; text-decoration:none; display:inline-table; color:red;">Pending Complaints
		<br />
		<?php
			$type = "pending";
			$p_count = $db->get_complaints_count($type);
		?>
		<label style="font-size:25px; margin-top:5px;"><?php echo $p_count; ?>
		</a>
		
		
	<h1 style="text-align:center; font-size:20px; font-weight:bold; color:orangered;">High Priority Emergency Complaints</h1>
		
	<div class="table-responsive row" style="background-color:#FFF">
	<table class="table table-bordered table-hover" id="example" style="overflow-x:auto;overflow-y:auto;" cellpadding=0 cellspacing=0>
		<thead class="thead-default thead-lg">
			<tr>
			    <th>Sr No</th>
				<th>User Details</th>
				<th>Complaint About</th>
				<th>Description</th>
				<th>Image One</th>
				<th>Image Two</th>
				<th>Status</th>
				<th >Date</th>
	            <th >Time</th>
				<th>Action</th>
            </tr>
		</thead>
		<tbody>
		<?php
			$status_type = "pending";
			$village	 = "";
			$complaint_type  =	"";
			$report_details = $db->get_all_complaint_records($status_type,$village,$complaint_type);
			if(!empty($report_details))
			{
				$counter =0;
				foreach($report_details as $record)
				{
					$id				=	$report_details[$counter][0];
					$user_id	=	$report_details[$counter][1];
					$complaint_about	=	$report_details[$counter][2];
					$description_one	=	$report_details[$counter][3];
					$image_one        =	$report_details[$counter][4];
					$image_two= $report_details[$counter][5];
				
					$date     =   $report_details[$counter][6];
				   $time  =   $report_details[$counter][7];
					$status	=	$report_details[$counter][8];
					$village	=	$report_details[$counter][9];
					$location =	$report_details[$counter][10];
					
					$data = $db->get_register_updated_data_from_mob_no($user_id);
					
					$name = "";
					$mob_no = "";
					$address = "";
					$email = "";
					$password = "";
					
					if(!empty($data))
					{
						$name = $data[1];
						$mob_no = $data[2];
						$address = $data[3];
						$email = $data[4];
						$password = $data[5];
					}
					
					if(strpos($complaint_about,'Pani')!== false)
					{
				
		?>
			 <tr class="odd gradeX">
				<td><?php echo $counter+1; ?></td>
				<td><?php echo $name."<br />".$mob_no."<br />".$address."<br />".$email; ?></td>
				<td><?php echo $complaint_about	; ?> <hr /> <?php echo $village; ?></td>
				<td><?php echo $description_one; ?>
				<br />
				<?php
					if($location!="")
					{
				?>
				Map : <a href="<?php echo $location; ?>" target="_blank">Click For Location</a>
				<?php
					}
				?>
				</td>
				<td>
				<?php if($image_one != "")
					{
					?>
					<a href="images/<?php echo $image_one; ?>" target="_blank"><img src="images/<?php echo $image_one; ?>" height="50px" width="50px"></a>
					<?php
					}else
					{
					?>
					<img src="logo/no-image.png" height="50px" width="50px"></a>
					<?php
					}
					?>
				</td>
				<td>
				<?php if($image_two != "")
					{
					?>
					<a href="images/<?php echo $image_two; ?>" target="_blank"><img src="images/<?php echo $image_two; ?>" height="50px" width="50px"></a>
					<?php
					}else
					{
					?>
					<img src="logo/no-image.png" height="50px" width="50px"></a>
					<?php
					}
					?>
				</td>
				<td>
					<label style="color:red;"><?php echo $status; ?></label>
					<br />
					<a href="<?php echo $_SERVER['PHP_SELF']."?complete_id=".$id; ?>" style='color:green;'>Set Complete</a>
				</td>
				<td><?php echo $date; ?></td>
				<td><?php echo $time; ?></td>
			
				<td class="center"><a href="complaint-list.php?delete_id=<?php echo $id;?>" onclick="return confirm('Are you sure?');"><i class="fas fa-trash-alt"style="color:red; margin-left:20px;"></i></a></td>
			</tr> 
			<?php
					}
				$counter++;
				}
			}else
			{
			?>
				<td colspan="7">No Data Found..</td>
			<?php
			}
			?>
		</tbody> 
	</table> 
</div>
		
		
		
		
		<?php
			}
		?>
		
            <?php include('footer.php'); ?>
        </div>
    </div>
    <!-- START SEARCH PANEL-->
    <?php //include('search.php'); ?>
    <!-- END SEARCH PANEL-->
    <!-- BEGIN THEME CONFIG PANEL-->
    
    <!-- END THEME CONFIG PANEL-->
    <!-- BEGIN PAGA BACKDROPS-->
    <div class="sidenav-backdrop backdrop"></div>
    <div class="preloader-backdrop">
        <div class="page-preloader">Loading</div>
    </div>
    <!-- END PAGA BACKDROPS-->
    <!-- New question dialog-->
    
    <!-- End New question dialog-->
    <!-- QUICK SIDEBAR-->
    <?php //include('right-side-bar.php'); ?>
    <!-- END QUICK SIDEBAR-->
    <!-- CORE PLUGINS-->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/metisMenu.min.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script src="js/idle-timer.min.js"></script>
    <script src="js/toastr.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/bootstrap-select.min.js"></script>
    <!-- PAGE LEVEL PLUGINS-->
    <!-- CORE SCRIPTS-->
    <script src="js/app.min.js"></script>
    <!-- PAGE LEVEL SCRIPTS-->
</body>

</html>